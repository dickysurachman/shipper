<?php

use yii\helpers\Html;

/* @var $this yii\web\View */
/* @var $model app\models\Status */
?>
<div class="status-update">

    <?= $this->render('_form', [
        'model' => $model,
    ]) ?>

</div>
