<?php

use yii\helpers\Html;


/* @var $this yii\web\View */
/* @var $model app\models\User */

?>
<div class="user-create">
    <?= $this->render('_form1', [
        'model' => $model,
    ]) ?>
</div>
